<?php
session_start();
if (isset($_POST['Login'])){

    $email = $_POST['email'];
    $pass = $_POST['password'];

    //t2akedna men login
 $link = mysqli_connect('localhost','root','','accessoires') ;

if(!$link) {
  echo 'connection error: ' . mysqli_connect_error();
  }
       $query="select * from clients where email='".$_POST['email']."' and password='".$_POST['password']." ";
        $result1 = mysqli_query($link,$query);

        $select="select * from admin where email='".$_POST['email']."' and password='".$_POST['password']." ";
        $result2 = mysqli_query($link,$select);

if (isset($_POST['password']) and isset($_POST['email'])) {
    if(empty($_POST['email'])|| empty($_POST['password']) ){
        header("location:connexion.php?Empty=Please fill in the blanks");
    }
        else if (mysqli_fetch_assoc($result1)){
          $_SESSION['User']=$_POST['email'];
            header("location:welcome.php");
        }
    

       else if (mysqli_fetch_assoc($result2)){
          $_SESSION['User']=$_POST['email'];
            header("location:admin.php");}
      
      
}

else {
    echo'not working now try again';
}







    }
  
      
?>