<?php
session_start();
if(!$_SESSION['User']){
    header("location:connexion.php");

}
?><?php 
$val1 = $_POST['cin'];
 $val0=$_POST['Ref'];
 $val3=$_POST['pa'];
 $val4=$_POST['nb'];

 $val2=$_POST['qte'];
$val5=1;

 ?><!DOCTYPE html>
 <html>
     <head>
     <meta charset="utf-8" />
     <link rel="stylesheet" href="produit.css"></link>
     <link rel="stylesheet" href="projet.css"></link>
     </head>
     <body>
         <div id="globale">
         <nav class="menu-nav">
                <ul id="menu"><div class="logo"><img src="images/NA.jpg" alt="" width="60px" height="40px">Nouhailas accessories
                    <li class="btn" ><a href="contact.html">Contact</a></li>
                    <li class="btn" ><a href="inscription.html">inscription</a></li>
                    <li class="btn" ><a href="">connexion</a></li>
                    <li class="btn"><a href="projet.html"> Acceuil</a></li></div>
                </ul>
            </nav>
            <div id="globale">
         <nav class="menu-nav">
                <ul id="menu">
                    <li class="btn" ><a href="info.php">mes info</a></li>
                    <li class="btn" ><a href="logout.php">Déconnexion</a></li>
                    <li class="btn" ><a href="commande.php">Commander un produit</a></li>
                    <li class="btn"><a href="listecomm.php">Mes commandes</a></li></div>
                </ul>
            </nav>
             <div>
             <?php

require_once('cnxBD.php');
$query1="select prix,REF from produits WHERE REF='$val0 ';";
if(mysqli_query($link, $query1)){
    $result1 = mysqli_query($link,$query1);

    while ($row=mysqli_fetch_assoc($result1)) {
        if($row['REF']==$_POST['Ref']){
            $val5=$val2*$row['prix'];  
         }
}}
$query="select *from produits WHERE REF='$val0 ';";
    if(mysqli_query($link, $query)){
        $result = mysqli_query($link,$query);
        while ($row=mysqli_fetch_assoc($result)) {
            if($row['REF']==$_POST['Ref']){
        $qte = ($row['quantité']-$val2);
        if($qte<0){
            echo'<h2>rupture de stock</h2> <br/>';}
            else{
                $insr ="INSERT INTO commandes(cin_client, REF, mode_payement,code_cart, qte, montant) VALUES ('$val1', '$val0','$val3','$val4','$val2','$val5');";
                if(mysqli_query($link, $insr)){
                    $up="UPDATE `produits` SET `quantité` = '$qte' WHERE `produits`.`REF` = '$val0'; ";

                    if(mysqli_query($link, $up)){
                        echo'<h2>Votre commande est validée</h2> <br/>';
                    }
                    else{
                        echo"Erreur :" .$up."<br/>" .mysqli_error($link);
                    }
                }
                else{
                    echo"Erreur :" .$insr."<br/>" .mysqli_error($link);

                }
            }
        }
} }



else{
    echo"Erreur :" .$insr."<br/>" .mysqli_error($link);
}
mysqli_close($link);
?>
<footer id = "footer">
          
          <!-- Company Details -->
          <!-- 1. Address 
               2. Contact Number
               3. Enquiry Mail 
          -->
          <div class="company-details">
              <div class="row">
                  <div id ="col1">
                      <span id = "icon" class="fa fa-map-marker"><img src="images/gps.png" alt="" width="40px" height="40px"></span>
                            
                      <span>
                          Route d'Eljadida,

                          <br />KM 7, CASABLANCA, Maroc
                      </span>
                  </div>
                        
                  <div id ="col2">
                      <span id="icon" class="fa fa-phone"><img src="images/tel.png" alt=""  width="40px" height="40px"></span>
        
                      <span>
                          Telephone: +212 665426496
                      </span>
                  </div>
                            
                  <div id ="col3">
                      <span id="icon" class="fa fa-envelope"><img src="images/gmail.png" alt=""  width="40px" height="40px"></span>
                      <span>Nouhailas.accessories@gmail.com</span>
                  </div>
                  <div id ="col4">
                      <span id="icon" class="fa fa-envelope"><img src="images/fc.png" alt=""  width="45px" height="45px"></span>
                      <span>Nouhailas.accessories</span>
                  </div>
              </div>
          </div>
                    
          <!-- Copyright Section -->
          <div class="copyright">
              <p>©  All rights reserved | Nouhailas accessories.</p>
            
          </div>
      </footer>



</body>

</html>