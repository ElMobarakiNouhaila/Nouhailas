
<!DOCTYPE html>
 <html>
     <head>
     <meta charset="utf-8" />
     <link rel="stylesheet" href="welcome.css"></link>
     <link rel="stylesheet" href="projet.css"></link>
     <link rel="stylesheet" href="connexion.css"></link>
     <link rel="stylesheet" href="css.css"></link>
     </head>
     <body>
         <div id="globale">
         <nav class="menu-nav">
                <ul id="menu"><div class="logo"><img src="images/NA.jpg" alt="" width="60px" height="40px">Nouhailas accessories
                    <li class="btn" ><a href="contact.html">Contact</a></li>
                    <li class="btn" ><a href="inscription.html">inscription</a></li>
                    <li class="btn" ><a href="">connexion</a></li>
                    <li class="btn"><a href="projet.html"> Acceuil</a></li></div>
                </ul>
            </nav>
           
<div id="globale">
         <nav class="menu-nav">
                <ul id="menu">
                <li class="btn" ><a href="logout.php">Déconnexion</a></li>
                    <li class="btn" ><a href="commandeclts.php">commande des clients</a></li>
                    <li class="btn" ><a href="">Mes clients</a></li>
                    <li class="btn" ><a href="contacts.php">Messages</a></li>
                    <li class="btn" ><a href="ajoutPRO.php">ajout produit</a></li>
                    <li class="btn" ><a href="deletePRO.php">Suppression produit</a></li>
                    <li class="btn" ><a href="bd.php">Stock</a></li>

                </ul>
            </nav><?php
session_start();
require_once('cnxBD.php');

if(!$_SESSION['User']){
    header("location:connexion.php");

}

                 $recupusers= "SELECT *FROM clients";
                 $result = mysqli_query($link,$recupusers);

                 echo '<table border="1"><tr><th>nom</th><th>prénom</th><th>cin</th><th>email</th><th>adresse</th><th>password</th></tr>';

                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    echo '<tr>';

                    echo '<td>';
                        echo $row['nom'];
                    echo '</td>';

                    echo '<td>';
                        echo $row['prénom'];
                    echo '</td>';

                    echo '<td>';
                        echo $row['cin'];
                    echo '</td>';

                    echo '<td>';
                        echo $row['email'];
                    echo '</td>';
                    echo '<td>';
                        echo $row['adresse'];
                    echo '</td>';

                    echo '<td>';
                        echo $row['password'];
                    echo '</td>';

                echo '</tr>';
                 }

		 		echo '</table>';
                 ?>
                 
                <footer id = "footer">
          <div class="company-details">
              <div class="row">
                  <div id ="col1">
                      <span id = "icon" class="fa fa-map-marker"><img src="images/gps.png" alt="" width="40px" height="40px"></span>
                            
                      <span>
                          Route d'Eljadida,

                          <br />KM 7, CASABLANCA, Maroc
                      </span>
                  </div>
                        
                  <div id ="col2">
                      <span id="icon" class="fa fa-phone"><img src="images/tel.png" alt=""  width="40px" height="40px"></span>
        
                      <span>
                          Telephone: +212 665426496
                      </span>
                  </div>
                            
                  <div id ="col3">
                      <span id="icon" class="fa fa-envelope"><img src="images/gmail.png" alt=""  width="40px" height="40px"></span>
                      <span>Nouhailas.accessories@gmail.com</span>
                  </div>
                  <div id ="col4">
                      <span id="icon" class="fa fa-envelope"><img src="images/fc.png" alt=""  width="45px" height="45px"></span>
                      <span>Nouhailas.accessories</span>
                  </div>
              </div>
          </div>
                    
          <!-- Copyright Section -->
          <div class="copyright">
              <p>©  All rights reserved | Nouhailas accessories.</p>
            
          </div>
      </footer>
</body>