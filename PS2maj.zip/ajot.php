<?php
 require_once('cnxBD.php');

session_start();
if(!$_SESSION['User']){
    header("location:connexion.php");

}
?>
<!DOCTYPE html>
 <html>
     <head>
     <meta charset="utf-8" />
     <link rel="stylesheet" href="projet.css"></link>
     <link rel="stylesheet" href="insc.css"></link>
         </head>
     <body>
         <div id="globale">
         <nav class="menu-nav">
                <ul id="menu"><div class="logo"><img src="images/NA.jpg" alt="" width="60px" height="40px">Nouhailas accessories
                    <li class="btn" ><a href="contact.html">Contact</a></li>
                    <li class="btn" ><a href="inscription.html">inscription</a></li>
                    <li class="btn" ><a href="">connexion</a></li>
                    <li class="btn"><a href="projet.html"> Acceuil</a></li></div>
                </ul>
            </nav>
 
<div id="globale">
         <nav class="menu-nav">
                <ul id="menu">
                <li class="btn" ><a href="logout.php">Déconnexion</a></li>
                    <li class="btn" ><a href="commandeclts.php">commande des clients</a></li>
                    <li class="btn" ><a href="clt.php">Mes clients</a></li>
                    <li class="btn" ><a href="contacts.php">Messages</a></li>
                    <li class="btn" ><a href="ajoutPRO.php">ajouter un produit</a></li>
                    <li class="btn" ><a href="deletePRO.php">Supprimer un produit</a></li>
                </ul>
            </nav>
<?php

$val1 = $_POST['reference'];
 $val0=$_POST['designation'];
 $val3 = $_POST['prix'];
 $val8 = $_POST['photo'];
 $val9 = $_POST['qte'];
 $val7 = $_POST['Categorie'];

 ?><center>
 <?php 
 $insr ="INSERT INTO produits(REF,Designation,prix,quantité,image,categorie) VALUES ('$val1', '$val0', '$val3','$val9', '$val8','$val7');";
 if(mysqli_query($link, $insr)){
     echo'ajout avec succes';

}
 else{
     echo"Erreur :" .$insr."<br/>" .mysqli_error($link);
 }
 ?></center>