<?php

$val1 = $_POST['reference'];
 ?><?php
             

 require_once('cnxBD.php');
 $insr ="DELETE FROM `produits` WHERE REF = '$val1'";
 if(mysqli_query($link, $insr)){
 ?><script type='text/javascript'>
 alert('SUPPRESSION AVEC SUCCES');
 </script><?php
header("location:admin.php");
                    }
 else{
     echo"Erreur :" .$insr."<br/>" .mysqli_error($link);
 }
 mysqli_close($link);
 ?>