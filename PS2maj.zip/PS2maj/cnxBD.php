<?php

$link=mysqli_connect("localhost", "root", "", "accessoires");
if(mysqli_connect_errno()){
 printf("Echec de la cnx : %s\n",mysqli_connect_errno());
}
?>