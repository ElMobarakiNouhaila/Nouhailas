-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 22 mai 2021 à 00:02
-- Version du serveur :  10.4.17-MariaDB
-- Version de PHP : 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `accessoires`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(20) NOT NULL,
  `cin` varchar(10) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `cin`, `nom`, `prenom`, `password`, `email`) VALUES
(1, 'BK1234', 'admin', 'add', '2000', 'admin@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE `clients` (
  `nom` varchar(100) NOT NULL,
  `prénom` varchar(100) NOT NULL,
  `cin` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `adresse` varchar(100) NOT NULL,
  `telephone` int(20) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `commandes`
--

CREATE TABLE `commandes` (
  `id_commande` int(100) NOT NULL,
  `cin_client` varchar(100) NOT NULL,
  `REF` varchar(100) NOT NULL,
  `mode_payement` varchar(100) NOT NULL,
  `qte` int(100) NOT NULL,
  `montant` int(200) DEFAULT NULL,
  `code_cart` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id_msg` int(100) NOT NULL,
  `nom_prénomClt` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telephone` varchar(100) NOT NULL,
  `messages` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id_msg`, `nom_prénomClt`, `email`, `telephone`, `messages`) VALUES
(1, 'abd nouhaila', 'nouhailaabdetouirsi@gmail.com', '0547821459', 'ma commande n pas ete valide\r\n'),
(2, 'abd nouhaila', 'nouhailaabdetouirsi@gmail.com', '0547821459', 'rtgutyuytfvgfooooo^ùmqsdft');

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

CREATE TABLE `produits` (
  `REF` varchar(10) NOT NULL,
  `Designation` varchar(100) NOT NULL,
  `prix` int(255) NOT NULL,
  `quantité` varchar(100) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `categorie` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `produits`
--

INSERT INTO `produits` (`REF`, `Designation`, `prix`, `quantité`, `image`, `categorie`) VALUES
('bag1', 'bague nœud papillon en argent', 510, '20', 'bag1.jpeg', 'bagues'),
('bag10', 'bague plaqué or blanc doré', 1000, '20', 'bag10.webp', 'bagues'),
('bag2', 'bague infini ', 520, '20', 'bag2.jpeg', 'bagues'),
('bag3', 'bague papillon', 370, '20', 'bag3.jpeg', 'bagues'),
('bag4', 'bague battement de cœur', 530, '20', 'bag4.jpeg', 'bagues'),
('bag5', 'bague diamands destinée ', 3850, '20', 'bag5.webp', 'bagues'),
('bag6', 'bague en or jaune', 953, '20', 'bag6.webp', 'bagues'),
('bag7', 'bague de fiançailles or blac', 1450, '20', 'bag7.jfif', 'bagues'),
('bag8', 'bague en argent sterling', 1500, '20', 'bag8.jpg', 'bagues'),
('bag9', 'bague or blan perle', 1156, '20', 'bag9.webp', 'bagues'),
('bo1', 'boucle d oreilles en argent forme plume', 390, '20', 'bo1.jpg', 'boucle'),
('bo10', 'Boucles D oreilles Pendantes Lysa Argent Blanc', 390, '20', 'bo10.jpg', 'boucle'),
('bo2', 'boucle d oreilles en diamande argent blanc  ', 150, '20', 'bo2.jpg', 'boucle'),
('bo3', 'Boucles D oreilles Puces Anne-maudae Coeurs Or Blanc', 190, '20', 'bo3.jpg', 'boucle'),
('bo4', 'Créoles Olympia Flexible Argent Blanc', 450, '20', 'bo4.jpg', 'boucle'),
('bo5', 'Créoles Muses Flexibles Or Jaune', 290, '20', 'bo5.webp', 'boucle'),
('bo6', 'Boucles D oreilles Pendantes ', 450, '20', 'bo6.jpg', 'boucle'),
('bo7', 'Boucles D oreilles Puces Cyriac Argent Blanc', 350, '20', 'bo7.jpg', 'boucle'),
('bo8', 'Boucles D oreilles Puces Ayana Argent Blanc', 190, '20', 'bo8.jpg', 'boucle'),
('bo9', 'Créoles Elvyn Argent Blanc', 250, '20', 'bo9.jpg', 'boucle'),
('bra1', 'Créoles Olympia Flexible Argent Blanc', 450, '19', 'bra1.jpg', 'bracelets'),
('bra10', ' bracelet argent', 990, '20', 'bra10.jpg', 'bracelets'),
('bra2', 'Bracelet jonc', 270, '20', 'bra2.jpg', 'bracelets'),
('bra3', 'Bracelet Barrette Gravable Or Bracelet Barrette Gravable Or Rose', 990, '20', 'bra3.jpg', 'bracelets'),
('bra4', 'Bracelet Anthia Argent Blanc Oxyde De Zirconium', 590, '20', 'bra4.jpg', 'bracelets'),
('bra5', 'Bracelet Jonc Edmoneae Plaque Or Jaune', 690, '20', 'bra5.jpg', 'bracelets'),
('bra6', 'Bracelet Jonc Nalah Plaque Or Jaune', 590, '20', 'bra6.jpg', 'bracelets'),
('bra7', 'Bracelet femme rosé or', 160, '20', 'bra7.jpg', 'bracelets'),
('bra8', 'sublime bracelet femme doré en or', 590, '20', 'bra8.jpg', 'bracelets'),
('bra9', 'bracelet argent femme', 690, '20', 'bra9.jpg', 'bracelets'),
('col1', 'collier cleor en argent', 690, '20', 'col1.jpg', 'colliers'),
('col10', 'collier en or jaune et diamants', 1370, '20', 'col10.jfif', 'colliers'),
('col2', 'collier cleor en or', 1500, '20', 'col2.jpg', 'colliers'),
('col3', 'collier solis en argent', 790, '20', 'col3.jpg', 'colliers'),
('col4', 'collier cleor en argent et oxyde', 490, '20', 'col4.jpg', 'colliers'),
('col5', 'collier en or de femme', 440, '20', 'col5.jfif', 'colliers'),
('col6', 'collier or doré et argenté', 450, '20', 'col6.jfif', 'colliers'),
('col7', 'collier perle', 250, '20', 'col7.jfif', 'colliers'),
('col8', 'collier en or femme ', 1370, '20', 'col8.jfif', 'colliers'),
('col9', 'collier en or', 1300, '20', 'col9.jfif', 'colliers'),
('lun1', 'lunettes solei classiques', 180, '20', 'lun1.jpg', 'lunettes'),
('lun10', 'lunettes de soleil yeux de chat', 210, '20', 'lun10.jpg', 'lunettes'),
('lun2', 'lunettes sde solei polarisées', 960, '20', 'lun2.jpg', 'lunettes'),
('lun3', 'lunettes de solei UV400', 250, '20', 'lun3.jpg', 'lunettes'),
('lun4', 'lunettes de solei carrées de luxe', 580, '20', 'lun4.jpg', 'lunettes'),
('lun5', 'lunettes de solei steampunk rondes', 350, '20', 'lun5.jpg', 'lunettes'),
('lun6', 'lunettes de soleil marque concepteur', 200, '20', 'lun6.jpg', 'lunettes'),
('lun7', 'lunettes de soleil en forme cœur ', 350, '20', 'lun7.jpg', 'lunettes'),
('lun8', 'lunettes de soleil classique', 250, '20', 'lun8.jpg', 'lunettes'),
('lun9', 'lunettes de soleil rondes sans bords', 360, '20', 'lun9.jpg', 'lunettes'),
('mon1', 'montre emporio armani', 1350, '20', 'mon1.jpg', 'montre'),
('mon10', 'montre guess collection GC', 1400, '20', 'mon10.jpg', 'montre'),
('mon2', 'montre Michael kors parker', 1400, '20', 'mon2.jpg', 'montre'),
('mon3', 'montre Michael kors parker MK5896', 1500, '20', 'MON3.jpg', 'montre'),
('mon4', 'montre Michael kors bronze', 1400, '20', 'mon4.jpg', 'montre'),
('mon5', 'montre emporio armani', 1400, '20', 'mon5.jpg', 'montre'),
('mon6', 'montre emporio armani retro', 1700, '20', 'mon6.jpg', 'montre'),
('mon7', 'montre emporio armani', 1350, '20', 'mon7.jpg', 'montre'),
('mon8', 'montre guess Y37002M1S', 1750, '20', 'mon8.jpg', 'montre'),
('mon9', ' montre guess Y16004L1', 1650, '20', 'mon9.jpg', 'montre');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `cin` (`cin`);

--
-- Index pour la table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`cin`);

--
-- Index pour la table `commandes`
--
ALTER TABLE `commandes`
  ADD PRIMARY KEY (`id_commande`);

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id_msg`);

--
-- Index pour la table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`REF`),
  ADD UNIQUE KEY `REF` (`REF`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `commandes`
--
ALTER TABLE `commandes`
  MODIFY `id_commande` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id_msg` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
