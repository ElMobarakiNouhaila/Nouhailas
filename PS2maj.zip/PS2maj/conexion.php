<?php
session_start();
$val1=$_POST['etat'];
?>

<!DOCTYPE html>
 <html>
     <head>
     <meta charset="utf-8" />
     <link rel="stylesheet" href="produit.css"></link>
     <link rel="stylesheet" href="projet.css"></link>
     </head>
     <body>
         <div id="globale">
         <nav class="menu-nav">
                <ul id="menu"><div class="logo"><img src="images/NA.jpg" alt="" width="60px" height="40px">Nouhailas accessories
                    <li class="btn" ><a href="contact.html">Contact</a></li>
                    <li class="btn" ><a href="inscription.html">inscription</a></li>
                    <li class="btn" ><a href="">connexion</a></li>
                    <li class="btn"><a href="projet.html"> Acceuil</a></li></div>
                </ul>
            </nav>
</div>
</body>
</html>
<?php
require_once('cnxBD.php');
if (isset($_POST['password']) and isset($_POST['nom'])and isset($_POST['etat'])) {
    if(empty($_POST['cin'])|| empty($_POST['password']) ||empty($_POST['etat'])  ){
        header("location:connexion.php?Empty=Remplir tous les champs");
    }
        else{
            if($val1=='visiteur'){
                $query="select *from clients where cin='".$_POST['cin']."' and password='".$_POST['password']."' and nom='".$_POST['nom']."' ";
        
                $result = mysqli_query($link,$query);
                if (mysqli_fetch_assoc($result)) {
                    $_SESSION['User']=$_POST['cin'];
                    header("location:welcome.php");
                    
                }
                else {
                    header("location:connexion.php?Invalid=Entrez des informations correctes");
                    
                
                }

            }
            else{
                $query="select *from admin where cin='".$_POST['cin']."' and password='".$_POST['password']."' and nom='".$_POST['nom']."' ";
        
                $result = mysqli_query($link,$query);
                if (mysqli_fetch_assoc($result)) {
                    $_SESSION['User']=$_POST['cin'];
                    header("location:admin.php");
                }
                else {
                    header("location:connexion.php?Invalid=please enter correct user name & password");
                    
                
                }
            }
       
    }
}

else {
    echo'not working now try again';
}?>


