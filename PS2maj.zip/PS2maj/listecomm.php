<!DOCTYPE html>
 <html>
     <head>
     <meta charset="utf-8" />
     <link rel="stylesheet" href="welcome.css"></link>
     <link rel="stylesheet" href="projet.css"></link>
     <link rel="stylesheet" href="connexion.css"></link>
     <link rel="stylesheet" href="list.css"></link>
     <link rel="stylesheet" href="css.css"></link>
     </head>
     <body>
         <div id="globale">
         <nav class="menu-nav">
                <ul id="menu"><div class="logo"><img src="images/NA.jpg" alt="" width="60px" height="40px">Nouhailas accessories
                    <li class="btn" ><a href="contact.html">Contact</a></li>
                    <li class="btn" ><a href="inscription.html">inscription</a></li>
                    <li class="btn" ><a href="">connexion</a></li>
                    <li class="btn"><a href="projet.html"> Acceuil</a></li></div>
                </ul>
            </nav>
             <div>

             <div id="globale">
         <nav class="menu-nav">
                <ul id="menu">
                    
                    <li class="btn" ><a href="logout.php">Déconnexion</a></li>
                    <li class="btn" ><a href="info.php">mes informations</a></li>
                    <li class="btn" ><a href="commande.php">Commander un produit</a></li>
                    <li class="btn"><a href="listecomm.php">Mes commandes</a></li>
                    <li class="btn" ><a href="welcome.php">Acceuil</a></li>
                </ul>
            </nav>
             <div class="tab">
                 
<?php
$link=mysqli_connect("localhost", "root", "", "accessoires");
if(mysqli_connect_errno()){
    printf("Echec de la cnx : %s\n",mysqli_connect_errno());
    exit();
}
$query = "select *from commandes,clients";
$result = mysqli_query($link,$query);

echo '<table border="1" ><tr><th>id_commande</th><th>cin_client</th><th>REF</th><th>qte</th><th>mode_payement</th><th>montant</th></tr>';
while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
    if($row['cin_client']==$row['cin']){
   echo '<tr>';

   echo '<td>';
       echo $row['id_commande'];
   echo '</td>';

   echo '<td>';
       echo $row['cin_client'];
   echo '</td>';

   echo '<td>';
       echo $row['REF'];
   echo '</td>';
   echo '<td>';
   echo $row['qte'];
echo '</td>';
   echo '<td>';
       echo $row['mode_payement'];
   echo '</td>';
   echo '<td>';
       echo $row['montant'];
       echo'MAD';
   echo '</td>';

echo '</tr>';
}}
echo '</table>';

mysqli_free_result($result);

mysqli_close($link);
?></div>

<footer id = "footer">
          
                <!-- Company Details -->
                <!-- 1. Address 
                     2. Contact Number
                     3. Enquiry Mail 
                -->
                <div class="company-details">
                    <div class="row">
                        <div id ="col1">
                            <span id = "icon" class="fa fa-map-marker"><img src="images/gps.png" alt="" width="40px" height="40px"></span>
                                  
                            <span>
                                Route d'Eljadida,

                                <br />KM 7, CASABLANCA, Maroc
                            </span>
                        </div>
                              
                        <div id ="col2">
                            <span id="icon" class="fa fa-phone"><img src="images/tel.png" alt=""  width="40px" height="40px"></span>
              
                            <span>
                                Telephone: +212 665426496
                            </span>
                        </div>
                                  
                        <div id ="col3">
                            <span id="icon" class="fa fa-envelope"><img src="images/gmail.png" alt=""  width="40px" height="40px"></span>
                            <span>Nouhailas.accessories@gmail.com</span>
                        </div>
                        <div id ="col4">
                            <span id="icon" class="fa fa-envelope"><img src="images/fc.png" alt=""  width="45px" height="45px"></span>
                            <span>Nouhailas.accessories</span>
                        </div>
                    </div>
                </div>
                          
                <!-- Copyright Section -->
                <div class="copyright">
                    <p>©  All rights reserved | Nouhailas accessories.</p>
                  
                </div>
            </footer>


</body>
</html>