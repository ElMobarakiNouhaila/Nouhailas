<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="lunettes.css"></link>
    <link rel="stylesheet" href="projet.css"></link>
<link rel="stylesheet" href="">
    </head>
    <body>
        <div id="globale">
            <nav class="menu-nav">
                <ul id="menu"><div class="logo"><img src="images/NA.jpg" alt="" width="60px" height="40px">Nouhailas accessories
                    <li class="btn" ><a href="contact.html">Contact</a></li>
                    <li class="btn" ><a href="inscription.html">inscription</a></li>
                     <li class="btn" ><a href="connexion.php">connexion</a></li>
                    <li class="btn"><a href="projet.html"> Acceuil</a></li></div>
                </ul>
            </nav>
            <div id="globale">
            <nav class="menu-nav">
                <ul id="menu">
                    <li class="btn" ><a href="bo.php">Boucles d'oreilles</a></li>
                    <li class="btn" ><a href="bagues.php">Bagues</a></li>
                    <li class="btn" ><a href="montre.php">Montres</a></li>
                    <li class="btn" ><a href="">Bracelets</a></li>
                    <li class="btn" ><a href="lunettes.php">lunettes</a></li>
                    <li class="btn"><a href="colliers.php"> colliers</a></li></div>
                </ul>
            </nav>
            <?php                                                            
require_once('cnxBD.php');
$query = "SELECT * FROM produits WHERE categorie='bracelets'";
$result = mysqli_query($link,$query);
if(mysqli_query($link, $query)){
	echo '<table><tr></tr>';
                 while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    echo '<tr>';

                    
                    echo '<td>';
                        echo '<img src="images/';?><?php echo $row['image'] ;?><?php echo' " />';
                    echo '</td>';
                    ?><div class="de"></div> <?php 
                    echo '<td><h5>';
                    echo 'Categorie:';
                    echo $row['categorie'];
                    echo '<br/>Prix:';
                    echo $row['prix'];
                    echo '<br/>Designation: ';
                    echo $row['Designation'];
                    echo '<br/>Reférence: ';
                    echo $row['REF'];
                    echo '<br/><button class="commander"><a href="connexion.php">commander ce produit</a></button></h5>
                </td>';

                echo '</tr>';
                 }

		 		echo '</table>';}
else{
    echo"Erreur :" .$query."<br/>" .mysqli_error($link);

}
                 ?>
                    
                </div></div>
    
                <footer id = "footer">
          
                    <!-- Company Details -->
                    <!-- 1. Address 
                         2. Contact Number
                         3. Enquiry Mail 
                    -->
                    <div class="company-details">
                        <div class="row">
                            <div id ="col1">
                                <span id = "icon" class="fa fa-map-marker"><img src="images/gps.png" alt="" width="40px" height="40px"></span>
                                      
                                <span>
                                    Route d'Eljadida,
    
                                    <br />KM 7, CASABLANCA, Maroc
                                </span>
                            </div>
                                  
                            <div id ="col2">
                                <span id="icon" class="fa fa-phone"><img src="images/tel.png" alt=""  width="40px" height="40px"></span>
                  
                                <span>
                                    Telephone: +212 665426496
                                </span>
                            </div>
                                      
                            <div id ="col3">
                                <span id="icon" class="fa fa-envelope"><img src="images/gmail.png" alt=""  width="40px" height="40px"></span>
                                <span>Nouhailas.accessories@gmail.com</span>
                            </div>
                            <div id ="col4">
                                <span id="icon" class="fa fa-envelope"><img src="images/fc.png" alt=""  width="45px" height="45px"></span>
                                <span>Nouhailas.accessories</span>
                            </div>
                        </div>
                    </div>
                              
                    <!-- Copyright Section -->
                    <div class="copyright">
                        <p>©  All rights reserved | Nouhailas accessories.</p>
                      
                    </div>
                </footer>
    
        </body></html>                                                        
                 
           


        