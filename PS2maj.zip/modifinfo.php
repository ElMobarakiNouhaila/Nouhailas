<!DOCTYPE html>
 <html>
     <head>
     <meta charset="utf-8" />
     <link rel="stylesheet" href="welcome.css"></link>
     <link rel="stylesheet" href="projet.css"></link>
     <link rel="stylesheet" href="insc.css"></link>

     <link rel="stylesheet" href="connexion.css"></link>


     </head>
     <body>
         <div id="globale">
         <nav class="menu-nav">
                <ul id="menu"><div class="logo"><img src="images/NA.jpg" alt="" width="60px" height="40px">Nouhailas accessories
                    <li class="btn" ><a href="contact.html">Contact</a></li>
                    <li class="btn" ><a href="inscription.html">inscription</a></li>
                    <li class="btn" ><a href="">connexion</a></li>
                    <li class="btn"><a href="projet.html"> Acceuil</a></li></div>
                </ul>
            </nav>
             <div><?php
require_once('cnxBD.php');
session_start();
if(!$_SESSION['User']){
    header("location:connexion.php");

}?>     <div id="globale">
<nav class="menu-nav">
       <ul id="menu">
           
           <li class="btn" ><a href="logout.php">Déconnexion</a></li>
           <li class="btn" ><a href="info.php">mes informations</a></li>
           <li class="btn" ><a href="commande.php">Commander un produit</a></li>
           <li class="btn"><a href="listecomm.php">Mes commandes</a></li>
           <li class="btn" ><a href="welcome.php">Acceuil</a></li>
       </ul>
   </nav>
   <div class="container">
   <h3>formulaire</h3>
            <h3>Si vous ne voulez modifier aucune donnée <button><a href="welcome.php">clicker ici </a></button></h3>
            <form method="post" action="modif.php" >
    <p><label for="nom">Nom</label>
        <input name="nom" placeholder="nom" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
        </p>

<p><label for="Prénom">Prénom</label>
<input name="Prénom" placeholder="Prénom" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
</p>
<p><label for="cin">CIN</label>
<input name="cin" placeholder="AB12345" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
</p>
<p><label for="email">Adresse email</label>
<input type="email" name="email" placeholder="abc@gmail.com" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
</p>
    <p><label for="adresse">Adresse</label>
<input name="adresse" placeholder="adresse" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->

<p><label for="Telephone">Telephone</label>
<input type="tel" name="Telephone" placeholder="0123456789" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
</p>
<label for="password">Password:</label>
<input type="password" name="password" placeholder="password" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
</p>
    <button class="ins">Modifier</button>

</form>  
</div>
             <div class="con">
<footer id = "footer">
          
<!-- Company Details -->
<!-- 1. Address 
     2. Contact Number
     3. Enquiry Mail 
-->
<div class="company-details">
    <div class="row">
        <div id ="col1">
            <span id = "icon" class="fa fa-map-marker"><img src="images/gps.png" alt="" width="40px" height="40px"></span>
                  
            <span>
                Route d'Eljadida,

                <br />KM 7, CASABLANCA, Maroc
            </span>
        </div>
              
        <div id ="col2">
            <span id="icon" class="fa fa-phone"><img src="images/tel.png" alt=""  width="40px" height="40px"></span>

            <span>
                Telephone: +212 665426496
            </span>
        </div>
                  
        <div id ="col3">
            <span id="icon" class="fa fa-envelope"><img src="images/gmail.png" alt=""  width="40px" height="40px"></span>
            <span>Nouhailas.accessories@gmail.com</span>
        </div>
        <div id ="col4">
            <span id="icon" class="fa fa-envelope"><img src="images/fc.png" alt=""  width="45px" height="45px"></span>
            <span>Nouhailas.accessories</span>
        </div>
    </div>
</div>
          
<!-- Copyright Section -->
<div class="copyright">
    <p>©  All rights reserved | Nouhailas accessories.</p>
  
</div>
</footer>
