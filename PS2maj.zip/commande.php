<?php
session_start();
if(!$_SESSION['User']){
    header("location:connexion.php");

}
?>

<!DOCTYPE html>
 <html>
     <head>
     <meta charset="utf-8" />
     <link rel="stylesheet" href="projet.css"></link>
     <link rel="stylesheet" href="insc.css"></link>
         </head>
     <body>
         <div id="globale">
         <nav class="menu-nav">
                <ul id="menu"><div class="logo"><img src="images/NA.jpg" alt="" width="60px" height="40px">Nouhailas accessories
                    <li class="btn" ><a href="contact.html">Contact</a></li>
                    <li class="btn" ><a href="inscription.html">inscription</a></li>
                    <li class="btn" ><a href="">connexion</a></li>
                    <li class="btn"><a href="projet.html"> Acceuil</a></li></div>
                </ul>
            </nav>

            <div id="globale">
         <nav class="menu-nav">
                <ul id="menu">
                    
                    <li class="btn" ><a href="logout.php">Déconnexion</a></li>
                    <li class="btn" ><a href="info.php">mes informations</a></li>
                    <li class="btn" ><a href="commande.php">Commander un produit</a></li>
                    <li class="btn"><a href="listecomm.php">Mes commandes</a></li>
                    <li class="btn" ><a href="welcome.php">Acceuil</a></li>
                </ul>
            </nav>
             <div>

             <div class="container">
             
             <h3 >Commander</h3>
             <?php
                    if(@$_GET['Empty']==true){
                 
                 ?>

                 <div class="alert-light text-danger text-center py-3"><?php echo $_GET['Empty']?></div>
                 <?php


                  }
                 
                 ?>
                 <?php
                    if(@$_GET['Invalid']==true){
                 
                 ?>

                 <div class="alert-light text-danger text-center py-3"><?php echo $_GET['Invalid']?></div>
                 <?php


                  }
                 
                 ?>
             <form method="post" action="commande1.php" >
                <p><label for="cin">CIN-client</label>
                <input name="cin" placeholder="BW1234"  > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
                </p>
                <p>
                <p><label for="Ref">REF-Produit</label><br><br>
                <input name="Ref" placeholder="AB1"  > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->

                </p>
                <p><label for="number">payement par carte bancaire:</br></br>*Numero de la carte</label>
                <input name="pa" placeholder="carte banc" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
                <p><label for="number">*Code de la carte</label>

                <input name="nb" placeholder="carte banc" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->

            </p>
                <p><label for="number">Quantité demandée</label>
                <input name="qte" placeholder="1"  > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
                </p>
                <p>
                <button class="connect">Commander</button>
                </p>
                </form>
    </div>
    <footer id = "footer">
          
                <!-- Company Details -->
                <!-- 1. Address 
                     2. Contact Number
                     3. Enquiry Mail 
                -->
                <div class="company-details">
                    <div class="row">
                        <div id ="col1">
                            <span id = "icon" class="fa fa-map-marker"><img src="images/gps.png" alt="" width="40px" height="40px"></span>
                                  
                            <span>
                                Route d'Eljadida,

                                <br />KM 7, CASABLANCA, Maroc
                            </span>
                        </div>
                              
                        <div id ="col2">
                            <span id="icon" class="fa fa-phone"><img src="images/tel.png" alt=""  width="40px" height="40px"></span>
              
                            <span>
                                Telephone: +212 665426496
                            </span>
                        </div>
                                  
                        <div id ="col3">
                            <span id="icon" class="fa fa-envelope"><img src="images/gmail.png" alt=""  width="40px" height="40px"></span>
                            <span>Nouhailas.accessories@gmail.com</span>
                        </div>
                        <div id ="col4">
                            <span id="icon" class="fa fa-envelope"><img src="images/fc.png" alt=""  width="45px" height="45px"></span>
                            <span>Nouhailas.accessories</span>
                        </div>
                    </div>
                </div>
                          
                <!-- Copyright Section -->
                <div class="copyright">
                    <p>©  All rights reserved | Nouhailas accessories.</p>
                  
                </div>
            </footer>

    </body>
    </html>