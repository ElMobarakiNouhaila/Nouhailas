<?php
session_start();
if(!$_SESSION['User']){
    header("location:connexion.php");

}
?>
<?php
if(isset($_POST["env"])){
$logo=$_FILES['photo']['name'];

if($logo!=""){
require "uploadImage.php";
if($sortie==false){$logo=$dest_dossier . $dest_fichier;}
else {$logo="notdid";}
}
if($logo!="notdid"){
echo "upload reussi!!!";

}
else{
echo"recommence!!!";
}
}

?>
<!DOCTYPE html>
 <html>
     <head>
     <meta charset="utf-8" />
     <link rel="stylesheet" href="projet.css"></link>
     <link rel="stylesheet" href="insc.css"></link>
         </head>
     <body>
         <div id="globale">
         <nav class="menu-nav">
                <ul id="menu"><div class="logo"><img src="images/NA.jpg" alt="" width="60px" height="40px">Nouhailas accessories
                    <li class="btn" ><a href="contact.html">Contact</a></li>
                    <li class="btn" ><a href="inscription.html">inscription</a></li>
                    <li class="btn" ><a href="">connexion</a></li>
                    <li class="btn"><a href="projet.html"> Acceuil</a></li></div>
                </ul>
            </nav>
 
<div id="globale">
         <nav class="menu-nav">
                <ul id="menu">
                <li class="btn" ><a href="logout.php">Déconnexion</a></li>
                    <li class="btn" ><a href="commandeclts.php">commande des clients</a></li>
                    <li class="btn" ><a href="clt.php">Mes clients</a></li>
                    <li class="btn" ><a href="contacts.php">Messages</a></li>
                    <li class="btn" ><a href="">ajout produit</a></li>
                    <li class="btn" ><a href="deletePRO.php">Suppression produit</a></li>
                    <li class="btn" ><a href="bd.php">Stock</a></li>
                </ul>
            </nav>
             <div>

             <div class="container">
            <h3>Insertion produit</h3>
            <form method="post" action="ajot.php" >
    <p><label for="text">reference</label>
        <input name="reference" placeholder="reference" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
        </p>

<p><label for="text">designation</label>
<input name="designation" placeholder="designation" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
</p>
<p><label for="number">prix</label>
<input type="prix" name="prix" placeholder="prix" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
</p>
<p><label for="photo">photo</label>
<input type="file" name="photo" placeholder="photo" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
</p>
<label for="number">qte:</label>
<input type="text" name="qte" placeholder="qte" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
</p>
</p>
<label for="number">Categorie:</label>
<input type="text" name="Categorie" placeholder="Categorie" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
</p>
<p>
<input type="submit" name="env" value='Ajouter'>
</p>
</div>
        <footer id = "footer">
          
                <!-- Company Details -->
                <!-- 1. Address 
                     2. Contact Number
                     3. Enquiry Mail 
                -->
                <div class="company-details">
                    <div class="row">
                        <div id ="col1">
                            <span id = "icon" class="fa fa-map-marker"><img src="images/gps.png" alt="" width="40px" height="40px"></span>
                                  
                            <span>
                                Route d'Eljadida,

                                <br />KM 7, CASABLANCA, Maroc
                            </span>
                        </div>
                              
                        <div id ="col2">
                            <span id="icon" class="fa fa-phone"><img src="images/tel.png" alt=""  width="40px" height="40px"></span>
              
                            <span>
                                Telephone: +212 665426496
                            </span>
                        </div>
                                  
                        <div id ="col3">
                            <span id="icon" class="fa fa-envelope"><img src="images/gmail.png" alt=""  width="40px" height="40px"></span>
                            <span>Nouhailas.accessories@gmail.com</span>
                        </div>
                        <div id ="col4">
                            <span id="icon" class="fa fa-envelope"><img src="images/fc.png" alt=""  width="45px" height="45px"></span>
                            <span>Nouhailas.accessories</span>
                        </div>
                    </div>
                </div>
                          
                <!-- Copyright Section -->
                <div class="copyright">
                    <p>©  All rights reserved | Nouhailas accessories.</p>
                  
                </div>
            </footer>

    </body>
    </html>