<!DOCTYPE html>
 <html>
     <head>
     <meta charset="utf-8" />
     <link rel="stylesheet" href="projet.css"></link>
     <link rel="stylesheet" href="insc.css"></link>
         </head>
     <body>
         <div id="globale">
         <nav class="menu-nav">
                <ul id="menu"><div class="logo"><img src="images/NA.jpg" alt="" width="60px" height="40px">Nouhailas accessories
                    <li class="btn" ><a href="contact.html">Contact</a></li>
                    <li class="btn" ><a href="inscription.html">inscription</a></li>
                    <li class="btn" ><a href="">connexion</a></li>
                    <li class="btn"><a href="projet.html"> Acceuil</a></li></div>
                </ul>
            </nav>
             <div class="container">
             
             <h3 >Connexion</h3>
             <?php
                    if(@$_GET['Empty']==true){
                 ?>
                 <div class="alert-light text-danger text-center py-3"><?php echo $_GET['Empty']?></div>
                 <?php
                  }
                 ?>
                 <?php
                    if(@$_GET['Invalid']==true){ 
                 ?>
                 <div class="alert-light text-danger text-center py-3"><?php echo $_GET['Invalid']?></div>
                 <?php
                  }
                 
                 ?>
             <form method="post" action="conexion.php" >
                <p><label for="nom">NOM</label>
                <input name="nom" placeholder="Nom" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
                </p>
                <p><label for="cin">CIN</label>
                <input name="cin" placeholder="BW1234" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
                </p>
                <label for="password">Password:</label>
                <input type="password" name="password" placeholder="password" required > <!--l'attribut required permet de rendre obligatoire le remplissage d'un champ et bloquer la validation -->
                </p>
                <input type="radio" name="etat" value="admin" id="admin" required>
        <label for="admin"> Adminstrateur</label>
        <input type="radio" name="etat" value="visiteur" id="visiteur">
        <label for="visiteur"> Visiteur</label>
                <button class="connect">Se connecter</button>
                </p>
                </form>
    </div>
    <footer id = "footer">
          
                <!-- Company Details -->
                <!-- 1. Address 
                     2. Contact Number
                     3. Enquiry Mail 
                -->
                <div class="company-details">
                    <div class="row">
                        <div id ="col1">
                            <span id = "icon" class="fa fa-map-marker"><img src="images/gps.png" alt="" width="40px" height="40px"></span>
                                  
                            <span>
                                Route d'Eljadida,

                                <br />KM 7, CASABLANCA, Maroc
                            </span>
                        </div>
                              
                        <div id ="col2">
                            <span id="icon" class="fa fa-phone"><img src="images/tel.png" alt=""  width="40px" height="40px"></span>
              
                            <span>
                                Telephone: +212 665426496
                            </span>
                        </div>
                                  
                        <div id ="col3">
                            <span id="icon" class="fa fa-envelope"><img src="images/gmail.png" alt=""  width="40px" height="40px"></span>
                            <span>Nouhailas.accessories@gmail.com</span>
                        </div>
                        <div id ="col4">
                            <span id="icon" class="fa fa-envelope"><img src="images/fc.png" alt=""  width="45px" height="45px"></span>
                            <span>Nouhailas.accessories</span>
                        </div>
                    </div>
                </div>
                          
                <!-- Copyright Section -->
                <div class="copyright">
                    <p>©  All rights reserved | Nouhailas accessories.</p>
                  
                </div>
            </footer>

    </body>
    </html>