<?php                                                            
require_once('cnxBD.php');
$query = "SELECT * FROM produits";
$result = mysqli_query($link,$query);
if(mysqli_query($link, $query)){
	echo '<table border="2" bgcolor=pink><tr><td>id_produit</td><td>designztion</td><td>prix</td><td>qte</td><td>photo</td><td>Categorie</td></tr>';
                 while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    echo '<tr>';

                    echo '<td>';
                        echo $row['REF'];
                    echo '</td>';

                    echo '<td>';
                        echo $row['Designation'];
                    echo '</td>';

                    echo '<td>';
                        echo $row['prix'];
                    echo '</td>';

                    echo '<td>';
                        echo $row['quantité'];
                    echo '</td>';
                    echo '<td>';
                        echo '<img src="images/';?><?php echo $row['image'] ;?><?php echo' " />';
                    echo '</td>';
                    
                    echo '<td>';
                        echo $row['categorie'];
                    echo '</td>';


                echo '</tr>';
                 }

		 		echo '</table>';}
else{
    echo"Erreur :" .$query."<br/>" .mysqli_error($link);

}
                 ?>