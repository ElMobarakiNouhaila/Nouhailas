<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8"/>
	</head>
	<body>
	<form name="fo" method="file" action="cc.php" enctype="multipart/form-data">
		<input type="file" name="image"/>
		<input type="submit" name="valider" value="charger"/>
		</form>
	</body>
	</html>